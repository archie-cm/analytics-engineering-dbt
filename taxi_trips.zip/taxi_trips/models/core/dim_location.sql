{{
  config(
    materialized='table',
    unique_key='location_id'
  )
}}

WITH cte as (
select
  distinct
  pickup_census_tract as location_id,
  pickup_community_area as community_area,
  pickup_latitude as latitude,
  pickup_longitude as longitude
from
  {{ ref('stg_table') }}

union distinct

select
  distinct
  dropoff_census_tract as location_id,
  dropoff_community_area as community_area,
  dropoff_latitude as latitude,
  dropoff_longitude as longitude
from
  {{ ref('stg_table') }}
)

SELECT * FROM cte WHERE location_id is NOT NULL