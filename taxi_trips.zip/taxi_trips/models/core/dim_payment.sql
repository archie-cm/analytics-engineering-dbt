{{

config(
    materialized='table',
    unique_key='payment_type'
)
}}

SELECT
  payment_type,
  tips
FROM (
  SELECT
    payment_type,
    AVG(tips) AS tips
  FROM
    {{ ref('stg_table') }}
  GROUP BY
    payment_type
)
WHERE payment_type IS NOT NULL