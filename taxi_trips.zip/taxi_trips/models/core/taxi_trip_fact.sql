-- taxi_trips_fact.sql
{{

config(
    materialized='table',
    unique_key='trip_id'
)
}}

SELECT
  unique_key as trip_id,
  pickup_community_area,
  dropoff_community_area,
  taxi_id,
  payment_type,
  EXTRACT(DATE FROM trip_start_timestamp) AS trip_date,
  EXTRACT(HOUR FROM trip_start_timestamp) AS trip_hour,
  trip_seconds,
  trip_miles,
  fare,
  tips,
  tolls,
  extras,
  trip_total
FROM
  {{ ref('stg_table') }}
