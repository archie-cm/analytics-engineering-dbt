{{

config(
    materialized='table',
    unique_key='taxi_id'
)
}}

SELECT
  taxi_id,
  company
FROM 
    {{ ref('stg_table') }}
