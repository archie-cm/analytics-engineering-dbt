{{ config(materialized='view') }}

select
    {{ dbt_utils.surrogate_key(['unique_key']) }} as tripid,
    *
from {{ source('staging','yellowtrip_data') }}